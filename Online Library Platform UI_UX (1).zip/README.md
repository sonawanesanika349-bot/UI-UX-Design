
  # Online Library Platform UI/UX

  This is a code bundle for Online Library Platform UI/UX. The original project is available at https://www.figma.com/design/kc9TVGi5lZK5eRTgigCyPD/Online-Library-Platform-UI-UX.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  