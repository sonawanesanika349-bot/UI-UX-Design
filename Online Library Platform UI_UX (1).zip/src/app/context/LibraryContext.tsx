import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Book, User, mockBooks, mockUser } from '../data/mockData';

interface LibraryContextType {
  books: Book[];
  user: User | null;
  isAuthenticated: boolean;
  borrowBook: (bookId: string) => void;
  returnBook: (bookId: string) => void;
  addToWishlist: (bookId: string) => void;
  removeFromWishlist: (bookId: string) => void;
  login: (email: string, password: string) => boolean;
  register: (name: string, email: string, password: string) => boolean;
  logout: () => void;
}

const LibraryContext = createContext<LibraryContextType | undefined>(undefined);

export const LibraryProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [books] = useState<Book[]>(mockBooks);
  const [user, setUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const borrowBook = (bookId: string) => {
    if (!user) return;
    
    const book = books.find(b => b.id === bookId);
    if (!book || !book.available) return;

    setUser(prev => {
      if (!prev) return prev;
      return {
        ...prev,
        borrowedBooks: [...prev.borrowedBooks, bookId],
        currentlyReading: [...prev.currentlyReading, bookId],
      };
    });

    // Update book availability and borrow count
    const bookIndex = books.findIndex(b => b.id === bookId);
    if (bookIndex !== -1) {
      books[bookIndex].available = false;
      books[bookIndex].borrowCount += 1;
    }
  };

  const returnBook = (bookId: string) => {
    if (!user) return;

    setUser(prev => {
      if (!prev) return prev;
      return {
        ...prev,
        borrowedBooks: prev.borrowedBooks.filter(id => id !== bookId),
        currentlyReading: prev.currentlyReading.filter(id => id !== bookId),
        readingHistory: [...new Set([...prev.readingHistory, bookId])],
      };
    });

    // Update book availability
    const bookIndex = books.findIndex(b => b.id === bookId);
    if (bookIndex !== -1) {
      books[bookIndex].available = true;
    }
  };

  const addToWishlist = (bookId: string) => {
    if (!user) return;

    setUser(prev => {
      if (!prev) return prev;
      if (prev.wishlist.includes(bookId)) return prev;
      return {
        ...prev,
        wishlist: [...prev.wishlist, bookId],
      };
    });
  };

  const removeFromWishlist = (bookId: string) => {
    if (!user) return;

    setUser(prev => {
      if (!prev) return prev;
      return {
        ...prev,
        wishlist: prev.wishlist.filter(id => id !== bookId),
      };
    });
  };

  const login = (email: string, password: string): boolean => {
    // Simple mock login - in real app, this would validate against backend
    if (email && password) {
      setUser(mockUser);
      setIsAuthenticated(true);
      return true;
    }
    return false;
  };

  const register = (name: string, email: string, password: string): boolean => {
    // Simple mock registration
    if (name && email && password) {
      const newUser: User = {
        id: 'user-' + Date.now(),
        name,
        email,
        borrowedBooks: [],
        wishlist: [],
        readingHistory: [],
        currentlyReading: [],
      };
      setUser(newUser);
      setIsAuthenticated(true);
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
    setIsAuthenticated(false);
  };

  return (
    <LibraryContext.Provider
      value={{
        books,
        user,
        isAuthenticated,
        borrowBook,
        returnBook,
        addToWishlist,
        removeFromWishlist,
        login,
        register,
        logout,
      }}
    >
      {children}
    </LibraryContext.Provider>
  );
};

export const useLibrary = () => {
  const context = useContext(LibraryContext);
  if (context === undefined) {
    throw new Error('useLibrary must be used within a LibraryProvider');
  }
  return context;
};
