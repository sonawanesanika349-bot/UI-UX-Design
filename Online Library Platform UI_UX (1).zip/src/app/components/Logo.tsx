import { BookOpen } from 'lucide-react';

export const Logo = ({ className = '' }: { className?: string }) => {
  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <div className="relative">
        <BookOpen className="w-8 h-8 text-blue-600" strokeWidth={2} />
        <div className="absolute -top-1 -right-1 w-2 h-2 bg-blue-400 rounded-full"></div>
      </div>
      <div className="flex flex-col">
        <span className="font-semibold text-lg leading-none tracking-tight">LibraVerse</span>
        <span className="text-xs text-gray-500 leading-none">Digital Library</span>
      </div>
    </div>
  );
};
