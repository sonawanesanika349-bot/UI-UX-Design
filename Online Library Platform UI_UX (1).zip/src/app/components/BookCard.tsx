import { Link } from 'react-router';
import { Heart, TrendingUp, BookOpen, CheckCircle } from 'lucide-react';
import { Book } from '../data/mockData';
import { useLibrary } from '../context/LibraryContext';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface BookCardProps {
  book: Book;
  showBorrowButton?: boolean;
}

export const BookCard = ({ book, showBorrowButton = false }: BookCardProps) => {
  const { user, addToWishlist, removeFromWishlist } = useLibrary();
  const isInWishlist = user?.wishlist.includes(book.id);
  const isBorrowed = user?.borrowedBooks.includes(book.id);

  const handleWishlistToggle = (e: React.MouseEvent) => {
    e.preventDefault();
    if (isInWishlist) {
      removeFromWishlist(book.id);
    } else {
      addToWishlist(book.id);
    }
  };

  return (
    <Link to={`/books/${book.id}`}>
      <div className="group bg-white rounded-xl border border-gray-200 overflow-hidden hover:shadow-lg transition-all duration-300 h-full flex flex-col">
        {/* Book Cover */}
        <div className="relative aspect-[2/3] bg-gradient-to-br from-blue-100 via-purple-50 to-pink-50 overflow-hidden">
          <ImageWithFallback
            src={book.coverUrl || `https://source.unsplash.com/400x600/?book,library&sig=${book.id}`}
            alt={book.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
          
          {/* Availability Badge */}
          <div className="absolute top-3 right-3">
            {book.available ? (
              <Badge className="bg-green-500 text-white border-0">
                <CheckCircle className="w-3 h-3 mr-1" />
                Available
              </Badge>
            ) : (
              <Badge variant="secondary">Borrowed</Badge>
            )}
          </div>

          {/* Wishlist Button */}
          {user && (
            <button
              onClick={handleWishlistToggle}
              className="absolute top-3 left-3 w-8 h-8 bg-white rounded-full flex items-center justify-center shadow-md hover:scale-110 transition-transform"
            >
              <Heart
                className={`w-4 h-4 ${
                  isInWishlist ? 'fill-red-500 text-red-500' : 'text-gray-400'
                }`}
              />
            </button>
          )}

          {/* Borrowed Indicator */}
          {isBorrowed && (
            <div className="absolute bottom-3 left-3 right-3 bg-blue-600 text-white text-xs py-1.5 px-3 rounded-lg flex items-center justify-center gap-1 font-medium">
              <BookOpen className="w-3 h-3" />
              Currently Borrowed
            </div>
          )}
        </div>

        {/* Book Info */}
        <div className="p-4 flex-1 flex flex-col">
          <h3 className="font-semibold text-gray-900 line-clamp-2 mb-1 group-hover:text-blue-600 transition-colors">
            {book.title}
          </h3>
          <p className="text-sm text-gray-600 mb-3">{book.author}</p>

          {/* Tags */}
          <div className="flex flex-wrap gap-2 mb-3">
            <Badge variant="outline" className="text-xs">
              {book.language}
            </Badge>
            <Badge variant="outline" className="text-xs">
              {book.category}
            </Badge>
          </div>

          {/* Borrow Count */}
          <div className="flex items-center gap-1 text-sm text-gray-600 mt-auto">
            <TrendingUp className="w-4 h-4 text-blue-600" />
            <span className="font-medium text-blue-600">{book.borrowCount.toLocaleString()}</span>
            <span>borrows</span>
          </div>
        </div>
      </div>
    </Link>
  );
};
