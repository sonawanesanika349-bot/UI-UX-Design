import { RouterProvider } from 'react-router';
import { LibraryProvider } from './context/LibraryContext';
import { router } from './routes';

export default function App() {
  return (
    <LibraryProvider>
      <RouterProvider router={router} />
    </LibraryProvider>
  );
}
