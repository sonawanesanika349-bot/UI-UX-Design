// Mock data for the online library platform

export interface Book {
  id: string;
  title: string;
  author: string;
  description: string;
  coverUrl: string;
  language: string;
  category: string;
  borrowCount: number;
  available: boolean;
  isbn: string;
  publishedYear: number;
}

export interface User {
  id: string;
  name: string;
  email: string;
  borrowedBooks: string[];
  wishlist: string[];
  readingHistory: string[];
  currentlyReading: string[];
}

export const categories = [
  "Fiction",
  "Non-Fiction",
  "Academic",
  "Science",
  "Technology",
  "History",
  "Biography",
  "Poetry",
  "Drama",
  "Children",
];

export const languages = [
  "English",
  "Hindi",
  "Marathi",
  "Sanskrit",
  "Tamil",
  "Bengali",
];

export const mockBooks: Book[] = [
  {
    id: "1",
    title: "The Digital Mind",
    author: "Dr. Sarah Chen",
    description:
      "An exploration of how technology shapes human consciousness and our relationship with knowledge in the digital age.",
    coverUrl:
      "https://images.unsplash.com/photo-1764391802461-90818239d401?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWNobm9sb2d5JTIwZGlnaXRhbCUyMG1pbmQlMjBib29rfGVufDF8fHx8MTc3NjQxNTQ4Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    language: "English",
    category: "Technology",
    borrowCount: 2847,
    available: true,
    isbn: "978-0-123456-78-9",
    publishedYear: 2023,
  },
  {
    id: "2",
    title: "Whispers of the Past",
    author: "Rajesh Kumar",
    description:
      "A compelling historical fiction that weaves together the stories of three generations during India's independence movement.",
    coverUrl:
      "https://images.unsplash.com/photo-1622266968713-e324b5e9f8af?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoaXN0b3JpY2FsJTIwZmljdGlvbiUyMGluZGlhJTIwYm9va3xlbnwxfHx8fDE3NzY0MTU0ODJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    language: "English",
    category: "Fiction",
    borrowCount: 3421,
    available: true,
    isbn: "978-0-234567-89-0",
    publishedYear: 2022,
  },
  {
    id: "3",
    title: "Quantum Mechanics Fundamentals",
    author: "Prof. James Wilson",
    description:
      "A comprehensive guide to understanding quantum mechanics, from basic principles to advanced applications.",
    coverUrl:
      "https://images.unsplash.com/photo-1754304342696-7c253db44456?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxxdWFudHVtJTIwcGh5c2ljcyUyMHNjaWVuY2UlMjB0ZXh0Ym9va3xlbnwxfHx8fDE3NzY0MTU0ODJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    language: "English",
    category: "Academic",
    borrowCount: 1893,
    available: true,
    isbn: "978-0-345678-90-1",
    publishedYear: 2021,
  },
  {
    id: "4",
    title: "आधुनिक भारत का इतिहास",
    author: "डॉ. अनिल शर्मा",
    description:
      "भारत के आधुनिक इतिहास की एक व्यापक समीक्षा, जो स्वतंत्रता संग्राम से लेकर समकालीन युग तक की यात्रा को दर्शाती है।",
    coverUrl:
      "https://images.unsplash.com/photo-1598796327099-29f362e3044a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYSUyMGhpc3RvcnklMjBib29rJTIwaGluZGl8ZW58MXx8fHwxNzc2NDE1NDgzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    language: "Hindi",
    category: "History",
    borrowCount: 2156,
    available: true,
    isbn: "978-0-456789-01-2",
    publishedYear: 2020,
  },
  {
    id: "5",
    title: "The Art of Mindfulness",
    author: "Maya Patel",
    description:
      "Discover the transformative power of mindfulness and meditation in modern life through practical exercises and wisdom.",
    coverUrl:
      "https://images.unsplash.com/photo-1589966837864-2ec85db4b225?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5kZnVsbmVzcyUyMG1lZGl0YXRpb24lMjB3ZWxsbmVzcyUyMGJvb2t8ZW58MXx8fHwxNzc2NDE1NDgzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    language: "English",
    category: "Non-Fiction",
    borrowCount: 4521,
    available: false,
    isbn: "978-0-567890-12-3",
    publishedYear: 2024,
  },
  {
    id: "6",
    title: "Cosmic Discoveries",
    author: "Dr. Neil Armstrong",
    description:
      "Journey through the latest discoveries in astronomy and space exploration, from black holes to exoplanets.",
    coverUrl:
      "https://images.unsplash.com/photo-1707581785966-650d2482fa63?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhc3Ryb25vbXklMjBzcGFjZSUyMGNvc21vcyUyMGJvb2t8ZW58MXx8fHwxNzc2NDE1NDg0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    language: "English",
    category: "Science",
    borrowCount: 2987,
    available: true,
    isbn: "978-0-678901-23-4",
    publishedYear: 2023,
  },
  {
    id: "7",
    title: "महाराष्ट्राचा इतिहास",
    author: "प्रा. विक्रम देशमुख",
    description:
      "महाराष्ट्राच्या समृद्ध सांस्कृतिक आणि ऐतिहासिक वारशाचे सविस्तर वर्णन.",
    coverUrl:
      "https://images.unsplash.com/photo-1663089555556-38b1fb22bb20?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWhhcmFzaHRyYSUyMGN1bHR1cmFsJTIwaGVyaXRhZ2UlMjBib29rfGVufDF8fHx8MTc3NjQxNTQ4NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    language: "Marathi",
    category: "History",
    borrowCount: 1654,
    available: true,
    isbn: "978-0-789012-34-5",
    publishedYear: 2019,
  },
  {
    id: "8",
    title: "Leadership in the 21st Century",
    author: "Michael Roberts",
    description:
      "Essential leadership principles and strategies for navigating the complexities of modern organizational challenges.",
    coverUrl:
      "https://images.unsplash.com/photo-1645245924084-d6cb34ad0687?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsZWFkZXJzaGlwJTIwYnVzaW5lc3MlMjBtYW5hZ2VtZW50JTIwYm9va3xlbnwxfHx8fDE3NzY0MTU0ODV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    language: "English",
    category: "Non-Fiction",
    borrowCount: 3102,
    available: true,
    isbn: "978-0-890123-45-6",
    publishedYear: 2023,
  },
  {
    id: "9",
    title: "The Silent Valley",
    author: "Priya Nair",
    description:
      "A gripping mystery set in the Western Ghats, where ancient secrets and modern crimes intertwine.",
    coverUrl:
      "https://images.unsplash.com/photo-1760696473709-a7da66ee87a6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxteXN0ZXJ5JTIwdGhyaWxsZXIlMjBub3ZlbCUyMGJvb2t8ZW58MXx8fHwxNzc2NDE1NDg1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    language: "English",
    category: "Fiction",
    borrowCount: 2734,
    available: true,
    isbn: "978-0-901234-56-7",
    publishedYear: 2024,
  },
  {
    id: "10",
    title: "Introduction to Machine Learning",
    author: "Dr. Amanda Lee",
    description:
      "A beginner-friendly introduction to machine learning concepts, algorithms, and practical applications.",
    coverUrl:
      "https://images.unsplash.com/photo-1591696331111-ef9586a5b17a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWNoaW5lJTIwbGVhcm5pbmclMjBhcnRpZmljaWFsJTIwaW50ZWxsaWdlbmNlJTIwYm9va3xlbnwxfHx8fDE3NzY0MTU0ODV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    language: "English",
    category: "Technology",
    borrowCount: 4123,
    available: true,
    isbn: "978-0-012345-67-8",
    publishedYear: 2023,
  },
  {
    id: "11",
    title: "Childhood Memories",
    author: "रवि वर्मा",
    description:
      "बचपन की यादों का एक मनोहारी संग्रह जो हर पाठक को अपने बचपन की याद दिला देगा।",
    coverUrl:
      "https://images.unsplash.com/photo-1589786015839-4bff535b37b4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwb2V0cnklMjBjb2xsZWN0aW9uJTIwdmludGFnZSUyMGJvb2t8ZW58MXx8fHwxNzc2NDE1NDg2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    language: "Hindi",
    category: "Poetry",
    borrowCount: 1432,
    available: true,
    isbn: "978-0-123456-78-0",
    publishedYear: 2022,
  },
  {
    id: "12",
    title: "The Biography of Gandhi",
    author: "Ramesh Gupta",
    description:
      "An in-depth biography of Mahatma Gandhi, exploring his philosophy, struggles, and lasting impact on the world.",
    coverUrl:
      "https://images.unsplash.com/photo-1617464071161-3b770974b926?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW5kaGklMjBiaW9ncmFwaHklMjBpbmRpYSUyMGJvb2t8ZW58MXx8fHwxNzc2NDE1NDg2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    language: "English",
    category: "Biography",
    borrowCount: 2876,
    available: true,
    isbn: "978-0-234567-89-1",
    publishedYear: 2021,
  },
  {
    id: "13",
    title: "Adventures in Wonderland",
    author: "Sophie Turner",
    description:
      "A magical children's story filled with adventure, friendship, and valuable life lessons.",
    coverUrl:
      "https://images.unsplash.com/photo-1613574841859-cbab4621150f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGlsZHJlbiUyMGFkdmVudHVyZSUyMGZhaXJ5JTIwdGFsZSUyMGJvb2t8ZW58MXx8fHwxNzc2NDE1NDg3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    language: "English",
    category: "Children",
    borrowCount: 3654,
    available: true,
    isbn: "978-0-345678-90-2",
    publishedYear: 2023,
  },
  {
    id: "14",
    title: "Environmental Science Today",
    author: "Dr. Green Walker",
    description:
      "Current environmental challenges and sustainable solutions for a better tomorrow.",
    coverUrl:
      "https://images.unsplash.com/photo-1600620165877-f69bc8e29fe7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbnZpcm9ubWVudGFsJTIwc2NpZW5jZSUyMG5hdHVyZSUyMGJvb2t8ZW58MXx8fHwxNzc2NDE1NDg3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    language: "English",
    category: "Science",
    borrowCount: 2145,
    available: true,
    isbn: "978-0-456789-01-3",
    publishedYear: 2024,
  },
  {
    id: "15",
    title: "The Lost Empire",
    author: "विजय पाटिल",
    description:
      "मराठा साम्राज्याच्या गौरवशाली इतिहासावर आधारित एक रोमांचक कादंबरी.",
    coverUrl:
      "https://images.unsplash.com/photo-1706269072121-5e8c109a677b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYXJhdGhhJTIwZW1waXJlJTIwaGlzdG9yaWNhbCUyMGJvb2t8ZW58MXx8fHwxNzc2NDE1NDg3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    language: "Marathi",
    category: "Fiction",
    borrowCount: 1987,
    available: false,
    isbn: "978-0-567890-12-4",
    publishedYear: 2022,
  },
  {
    id: "16",
    title: "Modern Poetry Collection",
    author: "Various Authors",
    description:
      "A curated collection of contemporary poetry from renowned poets around the world.",
    coverUrl:
      "https://images.unsplash.com/photo-1561981898-9c83401e4cfd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBwb2V0cnklMjBjb250ZW1wb3JhcnklMjBsaXRlcmF0dXJlfGVufDF8fHx8MTc3NjQxNTQ4OHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    language: "English",
    category: "Poetry",
    borrowCount: 1234,
    available: true,
    isbn: "978-0-678901-23-5",
    publishedYear: 2023,
  },
  {
    id: "17",
    title: "The Art of Code",
    author: "Thomas Anderson",
    description:
      "Master the craft of writing clean, efficient, and maintainable code with proven best practices.",
    coverUrl:
      "https://images.unsplash.com/photo-1484665739383-a1069a82d4be?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9ncmFtbWluZyUyMGNvZGUlMjBjb21wdXRlciUyMHNjaWVuY2UlMjBib29rfGVufDF8fHx8MTc3NjQxNTQ4OHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    language: "English",
    category: "Technology",
    borrowCount: 3789,
    available: true,
    isbn: "978-0-789012-34-6",
    publishedYear: 2024,
  },
  {
    id: "18",
    title: "Tales from the Village",
    author: "सीता देवी",
    description:
      "गाँव की जीवन शैली और परंपराओं पर आधारित कहानियों का एक संग्रह।",
    coverUrl:
      "https://images.unsplash.com/photo-1528195212522-e1c8bdeee617?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aWxsYWdlJTIwcnVyYWwlMjBpbmRpYSUyMHN0b3JpZXMlMjBib29rfGVufDF8fHx8MTc3NjQxNTQ4OHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    language: "Hindi",
    category: "Fiction",
    borrowCount: 1678,
    available: true,
    isbn: "978-0-890123-45-7",
    publishedYear: 2021,
  },
];

export const mockUser: User = {
  id: "user-1",
  name: "Arjun Sharma",
  email: "arjun.sharma@example.com",
  borrowedBooks: ["2", "5", "10"],
  wishlist: ["6", "8", "14", "17"],
  readingHistory: ["1", "3", "7", "11", "12"],
  currentlyReading: ["2", "10"],
};