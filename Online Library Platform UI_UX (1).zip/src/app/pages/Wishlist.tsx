import { useNavigate } from 'react-router';
import { Heart } from 'lucide-react';
import { useLibrary } from '../context/LibraryContext';
import { BookCard } from '../components/BookCard';
import { Button } from '../components/ui/button';

export const Wishlist = () => {
  const navigate = useNavigate();
  const { user, isAuthenticated, books } = useLibrary();

  if (!isAuthenticated || !user) {
    navigate('/login');
    return null;
  }

  const wishlistBooks = books.filter((book) => user.wishlist.includes(book.id));

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Heart className="w-8 h-8 text-red-500" />
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900">My Wishlist</h1>
          </div>
          <p className="text-gray-600">
            {wishlistBooks.length > 0
              ? `You have ${wishlistBooks.length} book${wishlistBooks.length === 1 ? '' : 's'} in your wishlist`
              : 'Your wishlist is empty'}
          </p>
        </div>

        {/* Wishlist Grid */}
        {wishlistBooks.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {wishlistBooks.map((book) => (
              <BookCard key={book.id} book={book} />
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-xl border border-gray-200 p-12 text-center">
            <Heart className="w-20 h-20 text-gray-300 mx-auto mb-4" />
            <h3 className="text-2xl font-semibold text-gray-900 mb-2">Your wishlist is empty</h3>
            <p className="text-gray-600 mb-8 max-w-md mx-auto">
              Start adding books you're interested in to your wishlist. Click the heart icon on any book to save it here.
            </p>
            <Button onClick={() => navigate('/books')} size="lg">
              Browse Books
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};
