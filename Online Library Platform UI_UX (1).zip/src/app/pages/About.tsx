import { BookOpen, Heart, Users, TrendingUp, CheckCircle, Sparkles } from 'lucide-react';
import { Link } from 'react-router';
import { Button } from '../components/ui/button';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

export const About = () => {
  const features = [
    {
      icon: BookOpen,
      title: 'Digital Borrowing',
      description: 'Borrow and return books digitally with just a click. No physical visits needed.',
    },
    {
      icon: Heart,
      title: 'Personal Wishlist',
      description: 'Save books you want to read later and get notified when they become available.',
    },
    {
      icon: TrendingUp,
      title: 'Track Popularity',
      description: 'See which books are trending and discover what others are reading.',
    },
    {
      icon: Users,
      title: 'Community Driven',
      description: 'Join thousands of readers in our vibrant digital library community.',
    },
  ];

  const benefits = [
    'No e-commerce - We\'re not a bookstore',
    'Free borrowing system',
    'Track your reading history',
    'Discover trending books',
    'Multiple language support',
    'Accessible anytime, anywhere',
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-50 via-white to-purple-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto">
            <div className="inline-flex items-center gap-2 bg-blue-100 text-blue-700 px-4 py-2 rounded-full text-sm font-medium mb-6">
              <Sparkles className="w-4 h-4" />
              About LibraVerse
            </div>
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Your Digital Library, Reimagined
            </h1>
            <p className="text-xl text-gray-600 leading-relaxed">
              LibraVerse is a modern online library platform designed to make reading accessible to everyone. We believe in the power of sharing knowledge, not selling it.
            </p>
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Our Mission & Vision
              </h2>
              <p className="text-lg text-gray-700 mb-6 leading-relaxed">
                At LibraVerse, we're on a mission to democratize access to knowledge. We believe that everyone deserves the opportunity to read, learn, and grow without financial barriers.
              </p>
              <p className="text-lg text-gray-700 mb-6 leading-relaxed">
                Unlike traditional e-commerce bookstores, we focus on the library experience - borrow, read, and return. Our platform tracks book popularity, helps you discover trending reads, and creates a community of passionate readers.
              </p>
              <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
                <h3 className="font-semibold text-blue-900 mb-2 flex items-center gap-2">
                  <CheckCircle className="w-5 h-5" />
                  Not an E-Commerce Platform
                </h3>
                <p className="text-blue-800">
                  We are NOT a bookstore. LibraVerse is a digital library where you can borrow and return books, just like a traditional library, but entirely online.
                </p>
              </div>
            </div>
            <div className="relative">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1582203914614-e23623afc345?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsaWJyYXJ5JTIwcmVhZGluZyUyMGJvb2tzfGVufDF8fHx8MTc3NjQxNDY2M3ww&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Library shelves"
                className="rounded-2xl shadow-xl"
              />
              <div className="absolute -bottom-6 -right-6 w-72 h-72 bg-blue-200 rounded-full filter blur-3xl opacity-20 -z-10"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              How It Works
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Experience a seamless digital library with features designed for modern readers
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature) => {
              const Icon = feature.icon;
              return (
                <div
                  key={feature.title}
                  className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg transition-shadow"
                >
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                    <Icon className="w-6 h-6 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">{feature.title}</h3>
                  <p className="text-gray-600">{feature.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="order-2 lg:order-1">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1759662280683-520528fb4c5a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZXJzb24lMjByZWFkaW5nJTIwYm9vayUyMHBlYWNlZnVsfGVufDF8fHx8MTc3NjQxNDY2NHww&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Person reading"
                className="rounded-2xl shadow-xl"
              />
            </div>
            <div className="order-1 lg:order-2">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Why Choose LibraVerse?
              </h2>
              <div className="space-y-4">
                {benefits.map((benefit) => (
                  <div key={benefit} className="flex items-start gap-3">
                    <CheckCircle className="w-6 h-6 text-green-600 flex-shrink-0 mt-0.5" />
                    <span className="text-lg text-gray-700">{benefit}</span>
                  </div>
                ))}
              </div>
              <div className="mt-8">
                <Link to="/register">
                  <Button size="lg" className="px-8">
                    Join LibraVerse Today
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-gradient-to-br from-blue-600 to-purple-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              Growing Together
            </h2>
            <p className="text-xl text-blue-100">
              Join our thriving community of book lovers
            </p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold text-white mb-2">5,000+</div>
              <div className="text-blue-100">Books Available</div>
            </div>
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold text-white mb-2">1,000+</div>
              <div className="text-blue-100">Active Readers</div>
            </div>
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold text-white mb-2">50,000+</div>
              <div className="text-blue-100">Books Borrowed</div>
            </div>
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold text-white mb-2">10+</div>
              <div className="text-blue-100">Categories</div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <BookOpen className="w-16 h-16 text-blue-600 mx-auto mb-6" />
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Ready to Start Reading?
          </h2>
          <p className="text-xl text-gray-600 mb-8">
            Create your free account and explore our vast collection of digital books today
          </p>
          <div className="flex flex-wrap gap-4 justify-center">
            <Link to="/register">
              <Button size="lg" className="px-8">
                Create Free Account
              </Button>
            </Link>
            <Link to="/books">
              <Button size="lg" variant="outline" className="px-8">
                Browse Library
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};
