import { useNavigate } from 'react-router';
import { BookOpen, Heart, History, User as UserIcon, TrendingUp, Book } from 'lucide-react';
import { useLibrary } from '../context/LibraryContext';
import { BookCard } from '../components/BookCard';
import { Button } from '../components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';

export const Dashboard = () => {
  const navigate = useNavigate();
  const { user, isAuthenticated, books } = useLibrary();

  if (!isAuthenticated || !user) {
    navigate('/login');
    return null;
  }

  const borrowedBooks = books.filter((book) => user.borrowedBooks.includes(book.id));
  const currentlyReadingBooks = books.filter((book) => user.currentlyReading.includes(book.id));
  const wishlistBooks = books.filter((book) => user.wishlist.includes(book.id));
  const historyBooks = books.filter((book) => user.readingHistory.includes(book.id));

  const stats = [
    {
      label: 'Currently Borrowed',
      value: borrowedBooks.length,
      icon: BookOpen,
      color: 'blue',
    },
    {
      label: 'Currently Reading',
      value: currentlyReadingBooks.length,
      icon: Book,
      color: 'green',
    },
    {
      label: 'Wishlist',
      value: wishlistBooks.length,
      icon: Heart,
      color: 'red',
    },
    {
      label: 'Reading History',
      value: historyBooks.length,
      icon: History,
      color: 'purple',
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="bg-gradient-to-br from-blue-600 to-purple-600 rounded-2xl p-8 md:p-12 mb-8 text-white">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
              <UserIcon className="w-8 h-8" />
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold">Welcome back, {user.name}!</h1>
              <p className="text-blue-100 mt-1">{user.email}</p>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat) => {
            const Icon = stat.icon;
            const colorClasses = {
              blue: 'bg-blue-50 text-blue-600 border-blue-200',
              green: 'bg-green-50 text-green-600 border-green-200',
              red: 'bg-red-50 text-red-600 border-red-200',
              purple: 'bg-purple-50 text-purple-600 border-purple-200',
            }[stat.color];

            return (
              <div
                key={stat.label}
                className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg transition-shadow"
              >
                <div className={`w-12 h-12 ${colorClasses} rounded-lg flex items-center justify-center mb-4`}>
                  <Icon className="w-6 h-6" />
                </div>
                <div className="text-3xl font-bold text-gray-900 mb-1">{stat.value}</div>
                <div className="text-sm text-gray-600">{stat.label}</div>
              </div>
            );
          })}
        </div>

        {/* Tabs */}
        <Tabs defaultValue="reading" className="space-y-6">
          <TabsList className="bg-white border border-gray-200">
            <TabsTrigger value="reading" className="gap-2">
              <BookOpen className="w-4 h-4" />
              Currently Reading
            </TabsTrigger>
            <TabsTrigger value="borrowed" className="gap-2">
              <Book className="w-4 h-4" />
              Borrowed Books
            </TabsTrigger>
            <TabsTrigger value="wishlist" className="gap-2">
              <Heart className="w-4 h-4" />
              Wishlist
            </TabsTrigger>
            <TabsTrigger value="history" className="gap-2">
              <History className="w-4 h-4" />
              Reading History
            </TabsTrigger>
          </TabsList>

          {/* Currently Reading */}
          <TabsContent value="reading">
            {currentlyReadingBooks.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {currentlyReadingBooks.map((book) => (
                  <BookCard key={book.id} book={book} />
                ))}
              </div>
            ) : (
              <div className="bg-white rounded-xl border border-gray-200 p-12 text-center">
                <BookOpen className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">No books currently reading</h3>
                <p className="text-gray-600 mb-6">Borrow a book to start reading</p>
                <Button onClick={() => navigate('/books')}>Browse Books</Button>
              </div>
            )}
          </TabsContent>

          {/* Borrowed Books */}
          <TabsContent value="borrowed">
            {borrowedBooks.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {borrowedBooks.map((book) => (
                  <BookCard key={book.id} book={book} />
                ))}
              </div>
            ) : (
              <div className="bg-white rounded-xl border border-gray-200 p-12 text-center">
                <Book className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">No borrowed books</h3>
                <p className="text-gray-600 mb-6">Browse our collection and borrow your first book</p>
                <Button onClick={() => navigate('/books')}>Browse Books</Button>
              </div>
            )}
          </TabsContent>

          {/* Wishlist */}
          <TabsContent value="wishlist">
            {wishlistBooks.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {wishlistBooks.map((book) => (
                  <BookCard key={book.id} book={book} />
                ))}
              </div>
            ) : (
              <div className="bg-white rounded-xl border border-gray-200 p-12 text-center">
                <Heart className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Your wishlist is empty</h3>
                <p className="text-gray-600 mb-6">Add books you want to read later</p>
                <Button onClick={() => navigate('/books')}>Browse Books</Button>
              </div>
            )}
          </TabsContent>

          {/* Reading History */}
          <TabsContent value="history">
            {historyBooks.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {historyBooks.map((book) => (
                  <BookCard key={book.id} book={book} />
                ))}
              </div>
            ) : (
              <div className="bg-white rounded-xl border border-gray-200 p-12 text-center">
                <History className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">No reading history yet</h3>
                <p className="text-gray-600 mb-6">Your completed books will appear here</p>
                <Button onClick={() => navigate('/books')}>Browse Books</Button>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};
