import { useParams, useNavigate, Link } from 'react-router';
import { Heart, ArrowLeft, BookOpen, Calendar, Globe, Tag, TrendingUp, CheckCircle, XCircle } from 'lucide-react';
import { useLibrary } from '../context/LibraryContext';
import { BookCard } from '../components/BookCard';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

export const BookDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { books, user, isAuthenticated, borrowBook, returnBook, addToWishlist, removeFromWishlist } = useLibrary();

  const book = books.find((b) => b.id === id);

  if (!book) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Book not found</h2>
          <Link to="/books">
            <Button>Browse Books</Button>
          </Link>
        </div>
      </div>
    );
  }

  const isInWishlist = user?.wishlist.includes(book.id);
  const isBorrowed = user?.borrowedBooks.includes(book.id);

  // Get related books (same category, exclude current)
  const relatedBooks = books
    .filter((b) => b.category === book.category && b.id !== book.id)
    .slice(0, 4);

  const handleBorrow = () => {
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }
    borrowBook(book.id);
  };

  const handleReturn = () => {
    returnBook(book.id);
  };

  const handleWishlistToggle = () => {
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }
    if (isInWishlist) {
      removeFromWishlist(book.id);
    } else {
      addToWishlist(book.id);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Back Button */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <button
            onClick={() => navigate(-1)}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Back
          </button>
        </div>
      </div>

      {/* Book Details */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">
        <div className="grid lg:grid-cols-2 gap-8 md:gap-12 mb-16">
          {/* Left: Book Cover */}
          <div>
            <div className="bg-white rounded-2xl border border-gray-200 p-6 md:p-8 sticky top-24">
              <div className="aspect-[2/3] bg-gradient-to-br from-blue-100 via-purple-50 to-pink-50 rounded-xl overflow-hidden mb-6">
                <ImageWithFallback
                  src={book.coverUrl || `https://source.unsplash.com/600x900/?book,library&sig=${book.id}`}
                  alt={book.title}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Action Buttons */}
              <div className="space-y-3">
                {isBorrowed ? (
                  <Button onClick={handleReturn} size="lg" className="w-full" variant="outline">
                    <CheckCircle className="w-5 h-5 mr-2" />
                    Return Book
                  </Button>
                ) : (
                  <Button
                    onClick={handleBorrow}
                    size="lg"
                    className="w-full"
                    disabled={!book.available}
                  >
                    {book.available ? (
                      <>
                        <BookOpen className="w-5 h-5 mr-2" />
                        Borrow Book
                      </>
                    ) : (
                      <>
                        <XCircle className="w-5 h-5 mr-2" />
                        Currently Unavailable
                      </>
                    )}
                  </Button>
                )}
                <Button
                  onClick={handleWishlistToggle}
                  variant="outline"
                  size="lg"
                  className="w-full"
                >
                  <Heart
                    className={`w-5 h-5 mr-2 ${isInWishlist ? 'fill-red-500 text-red-500' : ''}`}
                  />
                  {isInWishlist ? 'Remove from Wishlist' : 'Add to Wishlist'}
                </Button>
              </div>
            </div>
          </div>

          {/* Right: Book Info */}
          <div>
            <div className="mb-6">
              <div className="flex items-center gap-3 mb-4">
                <Badge className={book.available ? 'bg-green-500' : 'bg-gray-500'}>
                  {book.available ? 'Available' : 'Borrowed'}
                </Badge>
                {isBorrowed && <Badge className="bg-blue-600">You borrowed this</Badge>}
              </div>

              <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-3">{book.title}</h1>
              <p className="text-xl text-gray-600 mb-6">by {book.author}</p>

              {/* Tags */}
              <div className="flex flex-wrap gap-2 mb-8">
                <Badge variant="outline" className="gap-1.5">
                  <Tag className="w-3.5 h-3.5" />
                  {book.category}
                </Badge>
                <Badge variant="outline" className="gap-1.5">
                  <Globe className="w-3.5 h-3.5" />
                  {book.language}
                </Badge>
                <Badge variant="outline" className="gap-1.5">
                  <Calendar className="w-3.5 h-3.5" />
                  {book.publishedYear}
                </Badge>
              </div>

              {/* Borrow Count */}
              <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-8">
                <div className="flex items-center gap-2 text-blue-900">
                  <TrendingUp className="w-5 h-5" />
                  <span className="font-semibold text-lg">{book.borrowCount.toLocaleString()}</span>
                  <span className="text-blue-700">times borrowed</span>
                </div>
                <p className="text-sm text-blue-700 mt-1">This is a popular book in our library!</p>
              </div>

              {/* Description */}
              <div className="mb-8">
                <h2 className="text-xl font-semibold text-gray-900 mb-3">About this book</h2>
                <p className="text-gray-700 leading-relaxed">{book.description}</p>
              </div>

              {/* Book Details */}
              <div className="bg-white rounded-xl border border-gray-200 p-6">
                <h3 className="font-semibold text-gray-900 mb-4">Book Details</h3>
                <dl className="space-y-3">
                  <div className="flex justify-between border-b border-gray-100 pb-3">
                    <dt className="text-gray-600">ISBN</dt>
                    <dd className="font-medium text-gray-900">{book.isbn}</dd>
                  </div>
                  <div className="flex justify-between border-b border-gray-100 pb-3">
                    <dt className="text-gray-600">Language</dt>
                    <dd className="font-medium text-gray-900">{book.language}</dd>
                  </div>
                  <div className="flex justify-between border-b border-gray-100 pb-3">
                    <dt className="text-gray-600">Category</dt>
                    <dd className="font-medium text-gray-900">{book.category}</dd>
                  </div>
                  <div className="flex justify-between">
                    <dt className="text-gray-600">Published Year</dt>
                    <dd className="font-medium text-gray-900">{book.publishedYear}</dd>
                  </div>
                </dl>
              </div>
            </div>
          </div>
        </div>

        {/* Related Books */}
        {relatedBooks.length > 0 && (
          <section className="mt-16">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Related Books</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {relatedBooks.map((relatedBook) => (
                <BookCard key={relatedBook.id} book={relatedBook} />
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
};
