import { useState } from 'react';
import { Link } from 'react-router';
import { Search, BookOpen, TrendingUp, Sparkles, ArrowRight } from 'lucide-react';
import { useLibrary } from '../context/LibraryContext';
import { BookCard } from '../components/BookCard';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { categories } from '../data/mockData';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

export const Home = () => {
  const { books } = useLibrary();
  const [searchQuery, setSearchQuery] = useState('');

  // Get featured books (top 6 by borrow count)
  const featuredBooks = [...books]
    .sort((a, b) => b.borrowCount - a.borrowCount)
    .slice(0, 6);

  // Get popular books (top 8 by borrow count)
  const popularBooks = [...books]
    .sort((a, b) => b.borrowCount - a.borrowCount)
    .slice(0, 8);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      window.location.href = `/books?search=${encodeURIComponent(searchQuery)}`;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-gray-50">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-blue-50 via-white to-purple-50 py-20 md:py-28 overflow-hidden">
        <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left Content */}
            <div className="space-y-8">
              <div className="inline-flex items-center gap-2 bg-blue-100 text-blue-700 px-4 py-2 rounded-full text-sm font-medium">
                <Sparkles className="w-4 h-4" />
                Your Digital Reading Companion
              </div>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight">
                Explore, Borrow, and Read{' '}
                <span className="text-blue-600">Anytime, Anywhere</span>
              </h1>
              <p className="text-lg md:text-xl text-gray-600 leading-relaxed">
                Access thousands of books from our digital library. Borrow, read, and return books with ease. No purchases, just pure reading pleasure.
              </p>

              {/* Search Bar */}
              <form onSubmit={handleSearch} className="relative max-w-xl">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <Input
                  type="text"
                  placeholder="Search for books, authors, or categories..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-12 pr-4 py-6 text-base rounded-xl border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                />
              </form>

              {/* CTA Buttons */}
              <div className="flex flex-wrap gap-4">
                <Link to="/books">
                  <Button size="lg" className="rounded-xl px-8">
                    Browse Library
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Button>
                </Link>
                <Link to="/about">
                  <Button variant="outline" size="lg" className="rounded-xl px-8">
                    Learn More
                  </Button>
                </Link>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-6 pt-6">
                <div>
                  <div className="text-3xl font-bold text-blue-600">{books.length}+</div>
                  <div className="text-sm text-gray-600">Books Available</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-blue-600">{categories.length}+</div>
                  <div className="text-sm text-gray-600">Categories</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-blue-600">1000+</div>
                  <div className="text-sm text-gray-600">Active Readers</div>
                </div>
              </div>
            </div>

            {/* Right Image */}
            <div className="relative lg:block hidden">
              <div className="relative z-10">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1759662280683-520528fb4c5a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZXJzb24lMjByZWFkaW5nJTIwYm9vayUyMHBlYWNlZnVsfGVufDF8fHx8MTc3NjQxNDY2NHww&ixlib=rb-4.1.0&q=80&w=1080"
                  alt="Person reading in library"
                  className="rounded-2xl shadow-2xl"
                />
              </div>
              <div className="absolute -bottom-6 -right-6 w-72 h-72 bg-blue-200 rounded-full filter blur-3xl opacity-30"></div>
              <div className="absolute -top-6 -left-6 w-72 h-72 bg-purple-200 rounded-full filter blur-3xl opacity-30"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Books Section */}
      <section className="py-16 md:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-2">Featured Books</h2>
              <p className="text-gray-600">Discover our top picks for you</p>
            </div>
            <Link to="/books">
              <Button variant="outline">
                View All
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {featuredBooks.slice(0, 4).map((book) => (
              <BookCard key={book.id} book={book} />
            ))}
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-16 md:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-2">Browse by Category</h2>
            <p className="text-gray-600">Find books that match your interests</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {categories.map((category) => (
              <Link
                key={category}
                to={`/books?category=${encodeURIComponent(category)}`}
                className="group"
              >
                <div className="bg-gradient-to-br from-blue-50 to-purple-50 border border-gray-200 rounded-xl p-6 text-center hover:shadow-lg hover:border-blue-300 transition-all duration-300">
                  <BookOpen className="w-8 h-8 mx-auto mb-3 text-blue-600 group-hover:scale-110 transition-transform" />
                  <h3 className="font-semibold text-gray-900 group-hover:text-blue-600 transition-colors">
                    {category}
                  </h3>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Popular Books Section */}
      <section className="py-16 md:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-3 mb-8">
            <TrendingUp className="w-8 h-8 text-blue-600" />
            <div>
              <h2 className="text-3xl font-bold text-gray-900">Trending Now</h2>
              <p className="text-gray-600">Most borrowed books this month</p>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {popularBooks.map((book) => (
              <BookCard key={book.id} book={book} />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-blue-600 to-purple-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <BookOpen className="w-16 h-16 text-white mx-auto mb-6 opacity-90" />
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Start Your Reading Journey Today
          </h2>
          <p className="text-xl text-blue-100 mb-8">
            Join thousands of readers and get instant access to our digital library
          </p>
          <div className="flex flex-wrap gap-4 justify-center">
            <Link to="/register">
              <Button size="lg" variant="secondary" className="rounded-xl px-8">
                Sign Up Now
              </Button>
            </Link>
            <Link to="/books">
              <Button size="lg" variant="outline" className="rounded-xl px-8 bg-white/10 text-white border-white hover:bg-white hover:text-blue-600">
                Explore Library
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};
