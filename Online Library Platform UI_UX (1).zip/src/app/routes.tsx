import { createBrowserRouter } from 'react-router';
import { Layout } from './components/Layout';
import { Home } from './pages/Home';
import { BooksCollection } from './pages/BooksCollection';
import { BookDetail } from './pages/BookDetail';
import { Dashboard } from './pages/Dashboard';
import { Wishlist } from './pages/Wishlist';
import { Login } from './pages/Login';
import { Register } from './pages/Register';
import { About } from './pages/About';
import { NotFound } from './pages/NotFound';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: Layout,
    children: [
      { index: true, Component: Home },
      { path: 'books', Component: BooksCollection },
      { path: 'books/:id', Component: BookDetail },
      { path: 'dashboard', Component: Dashboard },
      { path: 'wishlist', Component: Wishlist },
      { path: 'about', Component: About },
      { path: '*', Component: NotFound },
    ],
  },
  {
    path: '/login',
    Component: Login,
  },
  {
    path: '/register',
    Component: Register,
  },
]);
